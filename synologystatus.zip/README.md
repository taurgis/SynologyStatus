# SynologyStatus
A Google Chrome plugin to see basic status information about your Synology NAS.

[![Code Climate](https://codeclimate.com/github/taurgis/SynologyStatus/badges/gpa.svg)](https://codeclimate.com/github/taurgis/SynologyStatus)
