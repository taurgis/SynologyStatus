var ticker;

$( document ).ready(function() {
    doTranslation();
    reloadMain();

   $('#login-submit').on('click', function(e) {
     var username = $('#login-form').find('#username').val();
     var password = $('#login-form').find('#password').val();
     var server = $('#login-form').find('#server').val();
     var ssl = $('#login-form').find('#ssl').prop('checked');

     chrome.storage.sync.set({'username': username}, function(result) {
       $('.dsminfo').hide();
       $('.loader').show();
       reloadMain();
     });

     chrome.storage.sync.set({'password': password});
     chrome.storage.sync.set({'server': server});
     chrome.storage.sync.set({'ssl': ssl});
   });

   $('#logout-button').on('click', function(result) {
    logout();

   });

   $('.close').on('click', function() {
     logout();
   });

  $('#login-form .form-control').keypress(function (e) {
    if (e.which == 13) {
      $('#login-submit').trigger('click');
    }
  });
});

function reloadMain() {
  chrome.storage.sync.get('username', function (result) {
      if(result.username) {
        $('.login-panel').hide();
        $('.logged-in-panel').show();

        $('.logged-in-as').text(chrome.i18n.getMessage("welcome") + result.username);

        fetchStatus(result.username);
      } else {
        $('.logged-in-panel').hide();
        $('.login-panel').show();
      }
  });
};

function fetchStatus(username) {
  chrome.storage.sync.get(['password', 'server', 'ssl'], function (storageresult) {
    var baseUrl = getBaseUrl(storageresult.server, storageresult.ssl);

    $.get( baseUrl + "/webapi/auth.cgi?api=SYNO.API.Auth&version=2&method=login&account=" + encodeURIComponent(username) + "&passwd=" + encodeURIComponent(storageresult.password) + "&session=DownloadStation&format=sid", function( data ) {

        var loginResult = JSON.parse(data);
        if(loginResult.success) {
          fetchDSMData(baseUrl, storageresult);

          ticker = setInterval(function(storageresult){
            fetchDSMData(baseUrl, storageresult, true);
            _gaq.push(['_trackPageview', '/refresh.html']);
          }, 5000, storageresult);
        } else {
          showError(chrome.i18n.getMessage("loginError"));
          $('.loader').hide();
        }
    }).error(function() {
      showError(chrome.i18n.getMessage("loginError"));
      $('.loader').hide();
    });
  });
}

function msToTime(s) {
  function addZ(n) {
     return (n<10? '0':'') + n;
   }

   var ms = s % 1000;
   s = (s - ms) / 1000;
   var secs = s % 60;
   s = (s - secs) / 60;
   var mins = s % 60;
   var hrs = (s - mins) / 60;

   return addZ(hrs) + ':' + addZ(mins) + ':' + addZ(secs) + '.' + ms;
}

function showError(message) {
  $('.logged-in-panel .alert').removeClass('alert-success');
  $('.logged-in-panel .alert').addClass('alert-danger');
  $('.logged-in-panel .alert .text').text(message);
  $('.logged-in-panel .alert').show();
}

var cpuChart;
var memoryChart;

function fetchDSMData(baseUrl, storageresult, reload) {
  $.get( baseUrl + "/webapi/dsm/info.cgi?api=SYNO.DSM.Info&version=1&method=getinfo", function( data ) {
    var infoResult = JSON.parse(data);

      if(infoResult.success) {
        $('.dsminfo').show();
        $('.loader').hide();
        $('.dsmmodel').text(infoResult.data.model);
        $('.dsmversion').text(infoResult.data.version);
        $('.dsmtemperature').text(infoResult.data.temperature);
      } else {
        showError("Error fetching DSM status!");
      }
  });
  $.get( baseUrl + "/webapi/_______________________________________________________entry.cgi?stop_when_error=false&compound=%5B%7B%22api%22%3A%22SYNO.Entry.Request%22%2C%22method%22%3A%22request%22%2C%22version%22%3A1%2C%22compound%22%3A%5B%7B%22api%22%3A%22SYNO.Core.AppNotify%22%2C%22method%22%3A%22get%22%2C%22version%22%3A1%7D%5D%7D%2C%7B%22api%22%3A%22SYNO.Core.System.Utilization%22%2C%22method%22%3A%22get%22%2C%22version%22%3A1%2C%22type%22%3A%22current%22%7D%5D&api=SYNO.Entry.Request&method=request&version=1" , function( data ) {
    var sysResult = data;
    var cpuPercentage = sysResult.data.result[1].data.cpu.other_load + sysResult.data.result[1].data.cpu.system_load + sysResult.data.result[1].data.cpu.user_load;
    $('.dsmprocessor').text(cpuPercentage + "%");
    $('.dsmmemory').text(sysResult.data.result[1].data.memory.real_usage + "%");
    $('.dsmdisk').text(sysResult.data.result[1].data.disk.total.utilization + "%")

    var dataCPU = [
        {
            value: cpuPercentage,
            color:"#F7464A",
            highlight: "#FF5A5E",
            label: "Used"
        },
        {
            value: 100 - cpuPercentage,
            color: "#eee",
            highlight: "#eee",
            label: "Unused"
        }
    ];

    var dataMemory = [
        {
            value: sysResult.data.result[1].data.memory.real_usage,
            color:"#F7464A",
            highlight: "#F7464A",
            label: "Used"
        },
        {
            value: 100 - sysResult.data.result[1].data.memory.real_usage,
            color: "#EEE",
            highlight: "#EEE",
            label: "Unused"
        }
    ];

    var dataDisk = [
        {
            value: sysResult.data.result[1].data.disk.total.utilization,
            color:"#F7464A",
            highlight: "#F7464A",
            label: "Used"
        },
        {
            value: 100 - sysResult.data.result[1].data.disk.total.utilization,
            color: "#EEE",
            highlight: "#EEE",
            label: "Unused"
        }
    ];

    var cpuCTX = document.getElementById("cpuChart").getContext("2d");
    var memoryCTX = document.getElementById("memoryChart").getContext("2d");
    var diskCTX = document.getElementById("diskChart").getContext("2d");

    if(reload) {
      cpuchart.segments[0].value=cpuPercentage;
      cpuchart.segments[1].value=100-cpuPercentage;
      cpuchart.update();

      memoryChart.segments[0].value=sysResult.data.result[1].data.memory.real_usage;
      memoryChart.segments[1].value=100-sysResult.data.result[1].data.memory.real_usage;
      memoryChart.update();

      diskChart.segments[0].value=sysResult.data.result[1].data.disk.total.utilization;
      diskChart.segments[1].value=100-sysResult.data.result[1].data.disk.total.utilization;
      diskChart.update();

    } else {
      cpuchart = new Chart(cpuCTX).Doughnut(dataCPU);
      memoryChart = new Chart(memoryCTX).Doughnut(dataMemory);
      diskChart = new Chart(diskCTX).Doughnut(dataDisk);
    }

    $('.loader').hide();
  });
}

function getBaseUrl(server, ssl) {
  if(validateUrl(server)) {
    return (ssl ? "https" : "http") + "://" + server;
  } else {
    return (ssl ? "https" : "http") + "://" + server + ".uk.quickconnect.to"
  }
}

function validateUrl(value){
	return (/^(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)$/gi.test(value)) || /^(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})$/gi.test(value);
}

function logout() {
  chrome.storage.sync.remove('username', function() {
    location.reload();
  });
}

function doTranslation() {
  $( "[data-translation]" ).each(function( index ) {
    var translation = chrome.i18n.getMessage($(this).data('translation'));
    $(this).text(translation);
  });

  $( "[data-translation-placeholder]" ).each(function( index ) {
    var translation = chrome.i18n.getMessage($(this).data('translation-placeholder'));
    $(this).attr('placeholder', translation);
  });
}
